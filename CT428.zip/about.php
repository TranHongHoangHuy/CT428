<?php
include './conn.php';
require './PHP/header.php';
?>

<iframe src="https://tranhonghoanghuy.github.io/groupCV/" scrolling="no"></iframe>
<style>
    iframe {
        width: 100%;
        height: 2500px;
        /* Kích thước của iframe tùy chỉnh */
    }
</style>
<?php include './PHP/footer.php'; ?>